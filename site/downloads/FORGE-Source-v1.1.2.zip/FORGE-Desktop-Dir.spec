# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['forge_desktop.py'],
    pathex=[],
    binaries=[],
    datas=[('forge\\skills_catalog', 'forge/skills_catalog')],
    hiddenimports=['forge.providers.groq', '_tkinter', 'forge.providers.gemini', 'forge.providers.ollama', 'forge.providers.deepseek', 'forge.providers.openrouter'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='FORGE-Desktop-Dir',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['assets\\forge-desktop-icon.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='FORGE-Desktop-Dir',
)
