#!/bin/bash
set -e
cd "$(dirname "$0")/FORGE"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3.10+ is required."
  exit 1
fi
python3 -m pip install --upgrade pip
python3 -m pip install .
echo "FORGE installed successfully."