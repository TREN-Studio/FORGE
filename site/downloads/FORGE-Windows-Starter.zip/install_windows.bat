@echo off
setlocal
cd /d "%~dp0FORGE"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 -m pip install --upgrade pip
  py -3 -m pip install .
  echo FORGE installed successfully.
  pause
  exit /b 0
)
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python -m pip install --upgrade pip
  python -m pip install .
  echo FORGE installed successfully.
  pause
  exit /b 0
)
echo Python 3.10+ is required. Install it from https://www.python.org/downloads/windows/
pause
exit /b 1