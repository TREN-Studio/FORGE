@echo off
setlocal
cd /d "%~dp0FORGE"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 -m forge.cli.main start
  exit /b %ERRORLEVEL%
)
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python -m forge.cli.main start
  exit /b %ERRORLEVEL%
)
echo Python 3.10+ is required. Install it first.
pause
exit /b 1